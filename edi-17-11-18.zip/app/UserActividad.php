<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserActividad extends Model
{
    protected $table = 'user_actividad';
}
