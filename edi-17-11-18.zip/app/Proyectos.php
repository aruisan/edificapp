<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Imagenes;

class Proyectos extends Model
{
    protected $table = 'proyectos';
}
