	@extends('layouts.dashboard')
	@section('content')
	<div class="formulario container col-sm-7 col-sm-offset-3 col-md-7 col-md-offset-3">
 aca va el crud de especialista mirando el historial de sus contratos  y el crud del cliente mirando sus cotizaciones
	</div>
	@stop