<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use AdamWathan\EloquentOAuth\Facades\OAuth;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

use App\User;

class principalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('layouts/principal');
    }

    public function facebook()
    {
        OAuth::login('facebook', function($user, $details) {      
        $user->name     = $details->full_name;
        $user->avatar   = $details->avatar;
        $user->email    = $details->email;
        $user->save();
        });
        $user = Auth::user();
        if(Auth::user()->rol == ""){
            return view('miCuenta/confirmacionOauth', ['user' => $user]);
        }else{
            return view('dashboard.index', ['user' => $user]);
        }
        
    }


    public function google()
    {

        OAuth::login('google', function($user, $details) {    
        $user->name     = $details->full_name;
        $user->avatar   = $details->avatar;
        $user->email    = $details->email;
        $user->save();
        });
        $user = Auth::user();
        if(Auth::user()->rol == ""){
            return view('miCuenta/confirmacionOauth', ['user' => $user]);
        }else{
            return view('dashboard.index', ['user' => $user]);
        }
    }

    public function tipoUser(Request $request)
    {
        $user = user::find(Auth::user()->id);
        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->rol      = $request->rol;
        $user->save();
        return view('dashboard.index', ['user' => $user]);
    }


    public function editarCuenta()
    {
        $user = Auth::user();
        return view('miCuenta/index', ['user' => $user]);
    }

    public function dashBoard()
    {
        $user = Auth::user();
        return view('dashboard.index', ['user' => $user]);
    }

//////////////////////////////////////////////////////////
    public function misEspecializaciones()
    {
        return view('especializaciones.index');
    }

    public function misContratos()
    {
        return view('especializaciones.index');
    }

    public function misCalificaciones()
    {
        return view('especialistas.calificaciones');
    }

    public function membresia()
    {
        return view('especialistas.membresias');
    }

    public function misProyectos()
    {
        return view('proyectos.index');
    }



//////////////////////////////////////////////////////////////
    public function misCotizaciones()
    {
        return view('cotizacion.create');
    }

    public function especialistas()
    {
        $user = Auth::user();
        return view('especialistas.buscar', ['user' => $user]);
    }



    
}
