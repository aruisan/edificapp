$(document).ready(function(){

	$('.especialidades').select2({
		closeOnSelect:true,
		theme:'classic',
	});

	$('.actividades').select2({
		closeOnSelect:true,
		theme:'classic',
	});

	$("#example-basic").steps({
    headerTag: "h3",
    bodyTag: "fieldset",
    transitionEffect: "slideLeft",
    autoFocus: true
		});

	var especialidad = {};
	especialidad['ARQ'] = ['Diseño Arquitectónico'];
	especialidad['DBARQ'] = ['Dibujo Arquitectónico', 'Dibujos 3D y Render'];
	especialidad['CONS'] = ['Gerencia de Proyectos de Construcción', 'Construcción Tradicional', 'Casas Prefabricadas', 'Cabañas de Madera', 'Demolición', 'Excavaciones y Movimientos de Tierra', 'Pisos en Concreto','Pavimentos', 'Estructuras Metálicas', 'Techos y Cubiertas', 'Recolección de Escombros', 'Pozos profundos'];
	especialidad['PINT'] = ['Pintura de Interiores', 'Pintura de Fachadas', 'Estucos Especiales'];
	especialidad['MAES'] = ['Maestro de Obra Certificado', 'Maestro de Obra Experimentado'];
	especialidad['ALB'] = ['Albañiles Expertos (Mampostería, Concreto, Pañete ó Repello)'];
	especialidad['REMO'] = ['Remodelación Integral (Completa)', 'Cocinas', 'Baños', 'Teatros en Casa (Home Theater)', 'Fachadas', 'Otros Ambientes']; 
	especialidad['CLIV'] = ['Instaladores de Drywall y Board (Muros Internos, Externos, Cielo rasos…)'];
	especialidad['CARP'] = ['Puertas', 'Centros de Entretenimiento', 'Camas', 'Closets', 'Cajoneras'];
	especialidad['ELECT']= ['Instalaciones Eléctricas nuevas', 'Mantenimiento y reparación de Instalaciones Eléctricas'];
	especialidad['PLOM'] = ['Plomeros expertos'];
	especialidad['PMAD'] = ['Madera Laminada', 'Pisos Deck'];
	especialidad['PVIN'] = ['Pisos Laminados en Vinilo y PVC', 'Pisos de Vinilo en rollo'];
	especialidad['PDEC'] = ['Concreto Decorativo','Concreto Estampado','Concreto Pulido', 'Pisos Epóxicos y Polimericos'];
	especialidad['PAPEL'] = ['Instaladores Papel de Colgadura','Instalación y Mantenimiento Alfombras'];
	especialidad['CORT'] = ['Suministro e Instalación Cortinas y Persianas ','Mantenimiento Cortinas'];
	especialidad['ILUM'] = ['Diseño e Instalación Iluminación Led'];
	especialidad['DISIN'] = ['Diseñadores de Interiores'];
	especialidad['COC'] = ['Diseño de Cocinas', 'Construcción Cocinas','Suministro e Instalación Equipos para Cocina', 'Mantenimiento Cocinas'];
	especialidad['CARPM'] = ['Carpintería Arquitectónica Metálica - Puertas, Ventanas', 'Carpintería de Acero', 'Carpintería de Aluminio'];
	especialidad['CARPVC'] = ['Carpintería Arquitectónica en PVC (Puertas y Ventanas)'];
	especialidad['IMP'] = ['Tanques (Agua Potable y otros)', 'Losas y Cubiertas', 'Jardineras', 'Parqueaderos'];
	especialidad['AIRE'] = ['Diseño Sistemas de Climatización', 'Instalación Aire Acondicionado', 'Mantenimiento Aire Acondicionado'];
	especialidad['JARD'] = ['Diseño de Jardines', 'Construcción Jardines','Mantenimiento Jardines'];
	especialidad['FACH'] = ['Instalación Fachadas con Paneles de Alumino compuesto - Tipo Alucobond', 'Otros revestimientos Arquitectónicos de Fachadas'];
	especialidad['PARA'] = ['Parasoles', 'Membranas Arquitectónicas', 'Toldos', 'Pergolas'];
	especialidad['PISCI'] = ['Construcción de Piscinas y Jacuzzis', 'Mantenimiento Piscinas y Jacuzzis', 'Saunas y Turcos'];
	especialidad['DOMO'] = ['Diseño Automatización','Montaje Domótica (Iluminación, Climatización, Audio, Video, CCTV, Persianas Motorizadas, Control Jacuzzis)', 'Cableado Estructurado', 'Sistemas de Vigilancia'];
	especialidad['TOPO'] = ['Levantamientos Topográficos'];
	especialidad['ESTSU'] = ['Estudios de Suelo'];
	especialidad['DISET'] = ['Cálculo y Diseño Estructural de Edificaciones'];
	especialidad['DISHI'] = ['Cálculo y Diseño Redes Acueducto Internas y Externas', 'Cálculo y Diseño Redes Alcantarillado Internas y Externas', 'Cálculo y Diseño de Pozos Sépticos', 'Cálculo y Diseño de Sistemas contra Incendio'];
	especialidad['DISEL'] = ['Cálculo y Diseño Redes Eléctricas'];
	especialidad['GAS'] = ['Instalación y Mantenimiento Gas Natural Domiciliario', 'Gas Propano','Biogas'];
	especialidad['AVAL'] = ['Avalúo Comercial','Avalúo Residencial'];
	especialidad['ASESO'] = ['Licencias de Construcción', 'Licencias de Urbanización', 'Licencias de Parcelación', 'Legalización de predios', 'Reglamentos de propiedad horizontal', 'Reloteo', 'Desenglobes', 'Estudio de titulos', 'Gestión de Subsidios de Mejoramiento de Vivienda', 'Gestión de Subisidios para Compra de Vivienda', 'Asesoría para compra de vivienda nueva o usada', 'Reclamos Postventa'];

 
	function ChangeList() {
	    var carList = document.getElementById("especialidades");
	    var modelList = document.getElementById("actividades");
	    var selCar = carList.options[carList.selectedIndex].value;
	    while (modelList.options.length) {
	        modelList.remove(0);
	    }
	    var cars = especialidad[selCar];
	    if (cars) {
	        var i;
	        for (i = 0; i < cars.length; i++) {
	            var car = new Option(cars[i], i);
	            modelList.options.add(car);
	        }
	    }
	}

	});

	function initMap() {
	        var uluru = {lat: 3.468547, lng:-76.523833 };
	        var map = new google.maps.Map(document.getElementById('map'), {
	          zoom: 18,
	          center: uluru
	        });
	        var marker = new google.maps.Marker({
	          position: uluru,
	          map: map
	        });
	      }

