	@extends('layouts.dashboard')
	@section('content')

bienvenido bla bla bla
	@stop