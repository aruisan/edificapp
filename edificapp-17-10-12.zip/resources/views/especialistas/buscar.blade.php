	@extends('layouts.dashboard')
	@section('content')
			<section>
				<div class="container">
					<h2 class="text-center">Especialistas</h2>

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">

								<p><span>Manuel Andrade</span></p>
								<p>Cali, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Premium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>5
									</li>
								</ul>

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:250
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Victor Ramirez</span></p>
								<p>Yumbo, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Rubiela Marin</span></p>
								<p>Palmira, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->
				</div>
			</section> <!--section Especialistas-->
				<section>
				<div class="container">
					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">

								<p><span>Manuel Andrade</span></p>
								<p>Cali, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Premium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>5
									</li>
								</ul>

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:250
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Victor Ramirez</span></p>
								<p>Yumbo, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Rubiela Marin</span></p>
								<p>Palmira, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->
				</div>
			</section> <!--section Especialistas-->
			<section>
				<div class="container">
					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">

								<p><span>Manuel Andrade</span></p>
								<p>Cali, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Premium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>5
									</li>
								</ul>

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:250
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Victor Ramirez</span></p>
								<p>Yumbo, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Rubiela Marin</span></p>
								<p>Palmira, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->
				</div>
			</section> <!--section Especialistas-->
			<section>
				<div class="container">
					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">

								<p><span>Manuel Andrade</span></p>
								<p>Cali, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Premium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>5
									</li>
								</ul>

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:250
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Victor Ramirez</span></p>
								<p>Yumbo, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->

					<div class="especialistas col-sm-4">
						<div class="row fila">
							<div class="col-sm-3 col-md-3">
								<img src="../../img/user.png" class="img-circle">
							</div>

							<div class="barras col-sm-9 col-md-9">
								<p><span>Rubiela Marin</span></p>
								<p>Palmira, Valle del Cauca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
								<p>Usuario Freemium</p>

								<ul class="list-unstyled list-inline">
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>1
							  		</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>2
									</li>
									<li>
										<i class="fa fa-star" aria-hidden="true"></i>3
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>4
									</li>
									<li>
										<i class="fa fa-star-o" aria-hidden="true"></i>5
									</li>
								</ul>	

								<div>
									<i class="fa fa-handshake-o fa-2x" aria-hidden="true"></i>Total clientes:50
								</div>
							</div><!--barras-->
						</div>
					</div><!--especialistas-->
				</div>
			</section> <!--section Especialistas-->
	@stop