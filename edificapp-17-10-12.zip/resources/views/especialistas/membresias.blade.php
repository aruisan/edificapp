	@extends('layouts.dashboard')
	@section('content')
	<section class="container">
				<h2 class="text-center">Membresias</h2>
				<div class="membresias owl-carousel owl-theme">
					<div class="panel panel-warning">
					  <div class="panel-heading">
						    <input type="checkbox" id="checkbox1" name="checkbox[]"/>
						    <label for="checkbox1"><a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Freemium</a></label>				
					  </div>
					  <div class="panel-body collapse" id="collapseOne"">
					    <ul>
					    	<li>Especialidades Inscritas: 2 Especialidades</li>
					    	<li>Galería de Proyectos: 2 Proyectos (de hasta 6 Imágenes cada uno)</li>
					    	<li>Visibilidad: Baja, después de los especialistas Premium</li>
					    	<li>Calificación de clientes: No</li>
					    	<li>Sellos: No*</li>
					    	<li>Prioridad atención a Aliados: No</li>
					    	<li>Tarifa: Gratis</li>
					    </ul>
					  </div>
					</div>
					
					<div class="panel panel-warning">
					  <div class="panel-heading">
					  	 <input type="checkbox" id="checkbox2" name="checkbox[]">
					  	 <label for="checkbox2"><a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Premium Light (Silver)</a></label>
					  </div>
					  <div class="panel-body collapse" id="collapseTwo"">
					    <ul>
					    	<li>Especialidades Inscritas: 8 Especialidades</li>
					    	<li>Galería de Proyectos: 5 Proyectos (de hasta 10 Imágenes cada uno)</li>
					    	<li>Visibilidad: Notable, Aparición preferente sobre los Freemium en los listados filtrados</li>
					    	<li>Calificación de clientes: si</li>
					    	<li>Sellos: si*</li>
					    	<li>Prioridad atención a Aliados: No</li>
					    	<li>Tarifa: </li>
					    </ul>
					  </div>
					</div>
					
					<div class="panel panel-warning">
					  <div class="panel-heading">
					  	 <input type="checkbox" id="checkbox3" name="checkbox[]">
					  	 <label for="checkbox3"><a data-toggle="collapse" data-parent="#accordion" href="#collapseTree">Premium Gold</a></label>
					  </div>
					  <div class="panel-body collapse" id="collapseTree">
					    <ul>
					    	<li>Especialidades Inscritas: Ilimitadas</li>
					    	<li>Galería de Proyectos: 16 Proyectos (de hasta 15 Imágenes cada uno)</li>
					    	<li>Visibilidad: Alta, Aparición prioritaria combinada con la membresía Premium Alliance</li>
					    	<li>Calificación de clientes: si</li>
					    	<li>Sellos: si*</li>
					    	<li>Prioridad atención a Aliados: No</li>
					    	<li>Tarifa: Gratis</li>
					    </ul>
					  </div>
					</div>
					
					<div class="panel panel-warning">
					  <div class="panel-heading">
					  	 <input type="checkbox" id="checkbox4" name="checkbox[]">
					  	 <label for="checkbox4"><a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">Premium Alliance</a></label>
					  </div>
					  <div class="panel-body collapse" id="collapseFour">
					    <ul>
					    	<li>Especialidades Inscritas: Ilimitadas</li>
					    	<li>Galería de Proyectos: 16 Proyectos (de hasta 15 Imágenes cada uno)</li>
					    	<li>Visibilidad: Alta, Aparición prioritaria para Clientes de la plataforma y exclusiva para clientes de Aliados</li>
					    	<li>Calificación de clientes: si</li>
					    	<li>Sellos: si*</li>
					    	<li>Prioridad atención a Aliados: si</li>
					    	<li>Tarifa: Gratis</li>
					    </ul>
					  </div>
					</div>
				</div>
			</section>
	@stop