	@extends('layouts.dashboard')
	@section('content')

<h1>aca va el crud de proyectos</h1>

	@stop