<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
//rutas principales
Route::get('/', 'principalController@index');

//rutas autenticacion
Route::post('registrar', [
		'uses' 	=> 'usuarioController@registro',
		'as'	=>	'registro'
]);

Route::get('login/{email}', [
		'uses' 	=> 'usuarioController@login',
		'as'	=>	'login'
]);






//ruta login registros apis
Route::get('auth_facebook', function(){ 
	return OAuth::authorize('facebook');
});
Route::get('login_facebook', 'principalController@facebook');

Route::get('auth_google', function(){ 
	return OAuth::authorize('google'); 
});
Route::get('oauth2callback', 'principalController@google');
Route::post('dashboard', [
		'uses' 	=> 'principalController@tipoUser',
		'as'	=>	'dashboard'
]);

/////////////////////////////////////////////////////////////////
Route::get('dashboard', [
		'uses' 	=> 'principalController@dashboard',
		'as'	=>	'dashboard'
]);
Route::get('miCuenta', [
		'uses' 	=> 'principalController@editarCuenta',
		'as'	=>	'miCuenta'
]);

////////////////////////////////////////////////////////////////
Route::get('misEspecializaciones', [
		'uses' 	=> 'principalController@misEspecializaciones',
		'as'	=>	'misEspecializaciones'
]);
Route::get('misContratos', [
		'uses' 	=> 'principalController@misContratos',
		'as'	=>	'misContratos'
]);
Route::get('misCalificaciones', [
		'uses' 	=> 'principalController@misCalificaciones',
		'as'	=>	'misCalificaciones'
]);
Route::get('misProyectos', [
		'uses' 	=> 'principalController@misProyectos',
		'as'	=>	'misProyectos'
]);
Route::get('membresia', [
		'uses' 	=> 'principalController@membresia',
		'as'	=>	'membresia'
]);
Route::get('buscarContratos', [
		'uses' 	=> 'principalController@buscarContratos',
		'as'	=>	'buscarContratos'
]);


//////////////////////////////////////////////////////////////////
Route::get('misCotizaciones', [
		'uses' 	=> 'principalController@misCotizaciones',
		'as'	=>	'misCotizaciones'
]);
Route::get('especialistas', [
		'uses' 	=> 'principalController@especialistas',
		'as'	=>	'especialistas'
]);

//////////////////////////////////////////////////////////

Route::get('salir', [
		'uses' 	=> 'principalController@getLogout',
		'as'	=>	'salir'
]);


