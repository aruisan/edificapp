	@extends('layouts.dashboard')
	@section('content')
	<div class="formulario container col-sm-7 col-sm-offset-3 col-md-7 col-md-offset-3">
<h1>aca va el crud de proyectos</h1>
	</div>
	@stop