<!Doctype html>

<html lang="ES">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Edificapp</title>

    	<!--Llamamos al archivo css a través de CDN-->
    	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    	
    	<link rel="stylesheet" href="../css/style.css">

    	<link rel="stylesheet" href="../css/jquery.steps.css">

    	<!-- Llamamos al css de la libreria select2-->
    	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />

    	<!-- Llamamos al css de la libreria owlcarousel-->
    	<link rel="stylesheet" href="../css/owl.carousel.css" />
    	<link rel="stylesheet" href="../css/owl.theme.default.css" />	
	</head>

	<body>
		<div class="conten">

			<header>
				<h1 hidden=>Edificapp</h1>
					

				<nav class="navbar" role="navigation" id="navbar" data-spy="affix" data-offset-top="100">
					<div class="container-fluid navegacion">
						<div class="container">
							<div class="navbar-header">
								<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse">
			                        <span class="sr-only">Toggle navigation</span>
			                        <i class="fa fa-bars fa-2x"></i>
			                        
			                    </button>
								<a class="navbar-brand" href="#inicio"></a>

								<i class="boton fa fa-caret-square-o-left fa-2x"></i>
							</div><!--navbar-header-->									
							
							<div class="collapse navbar-collapse" id="collapse">
								<ul class="nav navbar-nav navbar-right">
									<li><a href="../index.html"><i class="fa fa-home fa-fw" aria-hidden="true"></i>Inicio</a></li>
									<li><a href="#directorio">Directorio de Especialistas</a></li>
									<li><a href="../cliente/cliente.html">Solicita Cotización</a></li>
									<li><a href="#inicio">Ideas Inspiradoras</a></li>
									<li><a href="#inicio">Blog</a></li>
									<li><a href="#inicio">Ayuda</a></li>
								</ul>
							</div> <!--collapse-->
						</div>	

					</div><!--container navegacion-->
				</nav>
				<!--fin Barra Navegación-->				
			</header>

			<div class="container-fluid" id="enlace">
				<div class="container">
					<div class="col-sm-6 col-md-6">
						<p>¿QUIERES QUE TU PERFIL COMO PROFESIONAL SEA EL MAS VISTO?</p>
					</div>
					<div class="col-sm-6 col-md-6">
						<a href="membresia" class="btn btn-lg col-md-12" role="button">Conoce nuestros planes</a>
					</div>		
				</div>
			</div> <!--container enlace-->

			<div class="barra-lateral">
				<section>
					<aside>
						<div class="user-info">
							<div>
								<img class="img-circle" src="{{ Auth::user()->avatar }}" width="80">
							</div>
							<div class="container-info">
								<p>{{ Auth::user()->name }}</p>
								<p>{{ Auth::user()->email }}</p>
							</div>
						</div><!--user info-->
						<nav class="navbar" role="navigation" id="navbar">
							<div class="container-fluid navegacion">
								<div class="container">
									<div class="navbar-header">
										<a class="navbar-brand" href="#inicio"><h1></h1></a>
									</div><!--navbar-header aside-->									

									<div>
										<ul class="nav">
											<li><a href="dashboard"><i class="fa fa-home fa-fw"></i>DashBoard</a></li>
											<li><a href="miCuenta">Mi Cuenta</a></li>
										@if (Auth::user()->rol == "especialista")
											<li><a href="misEspecializaciones">Mis Especializaciones</a></li>
											<li><a href="misContratos">Mis Contratos</a></li>
											<li><a href="misCalificaciones">Mis Calificaciones</a></li>
											<li><a href="misProyectos">Mis Proyectos</a></li>
											<li><a href="contratos">Encuentra Contratos</a></li>
											<li><a href="membresia">Membresia</a></li>
										@endif
											<li><a href="misCotizaciones">Crea un proyecto</a></li>
											<li><a href="especialistas">Encuentra Especialistas</a></li>
											<li><a href="salir">Salir</a></li>
										</ul>
									</div> <!--collapse aside-->
								</div>
							</div><!--container navegacion aside-->
						</nav>
					<!--fin Barra Navegación aside-->
					</aside>
				</section>
			</div><!-- barra lateral-->
			
			<div class="contenido">				
					@yield('content')	
			</div><!--contenido-->

		<!-- JQuery CDN-->
    	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    	
    	<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

		<!--Llamamos al archivo Font Awesome CDN-->
    	<script src="https://use.fontawesome.com/bb6d0f8827.js"></script>

    	<!--script select2-->	
		<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

		<!--script steps-->	
		<script type="text/javascript" src="../js/jquery.steps.js"></script>

		<!--script owlcarousel-->	
		<script type="text/javascript" src="../js/owl.carousel.js"></script>

		<script type="text/javascript" src="../js/javascript.js"></script>

		<!--script maps-->
		<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAA7eOJkGoZwWlSiCIbEltXu4ljUhw1Ftg&callback=initMap"></script>
		
	</body>

</html>

